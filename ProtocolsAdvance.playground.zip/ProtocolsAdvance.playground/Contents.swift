import UIKit

protocol Likeable {
    var likeCount: Int { get }
    var ownerId: String { get }
}

class Comment {
    var id: String!
    var createdAd: Date!
}

class Photo {
    var id: String!
    var createdAd: Date!
}

extension Likeable where Self: Comment {
    var likeCount: Int {
        return 100
    }
}

extension Likeable where Self: Photo {
    var likeCount: Int {
        return 200
    }
}

class Guest: Comment, Likeable {
    var ownerId: String = ""
}

class Account: Photo, Likeable {
    var ownerId: String = ""
}

var account1 = Account()
print("\(account1.likeCount)")

var guest1 = Guest()
print("\(guest1.likeCount)")

//-----------------------------
//Protocol'ün Protocol'ü Confirm Etmesi.

protocol Protocol1 {
    var name: String { get }
}
protocol Protocol2: Protocol1 {
    var age: Int { get set }
}

class Class1: Protocol1 {
    var name: String = ""
}

class Class2: Protocol2 {
    var age: Int = 0
    var name: String = ""
}

